package br.com.teste.desafio_eawe.controller;

import br.com.teste.desafio_eawe.model.Modelo;
import br.com.teste.desafio_eawe.repositories.JpaRepEawe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.time.LocalDate;

@RestController
@RequestMapping(path="/api")
public class Controler {

@Autowired
    private JpaRepEawe jpaRepEawe;

@PostMapping("/gravar/{arquivo}")
    public void gravar(@PathVariable String arquivo)  throws ParserConfigurationException {
        Modelo modelo = new Modelo();
        try {
            String nomearq = arquivo+".xml";
            File file = new File(nomearq);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.parse(file);
            document.getDocumentElement().normalize();
            NodeList nList = document.getElementsByTagName("agente");
            NodeList nodeList = document.getElementsByTagName("regiao");

            for (int i = 0; i < nList.getLength(); i++) {
                for (int j = 0; j < nodeList.getLength(); j++) {
                    Node nxml = nList.item(i);
                    Node node = nodeList.item(j);
                    Element element = (Element) nxml;
                    Element nelement = (Element) node;
                    modelo.setCodigo(Integer.valueOf(element.getAttribute("codigo")));
                    modelo.setData(LocalDate.parse(element.getAttribute("data")));
                    modelo.setRegiao_sigla(nelement.getAttribute("sigla"));
                    modelo.setGeracao_valor(Double.parseDouble(element.getAttribute("geracao")));
                    modelo.setCompra_valor(Double.parseDouble(element.getAttribute("compra")));
                    modelo.setPrecoMedio(Double.parseDouble(element.getAttribute("precoMedio")));
                }
            }
        } catch (IOException | SAXException ex) {
            throw new RuntimeException(ex);
        }

        jpaRepEawe.save(modelo);

    }
}
