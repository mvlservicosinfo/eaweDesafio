package br.com.teste.desafio_eawe;

import br.com.teste.desafio_eawe.controller.Controler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;

@SpringBootApplication
public class DesafioEaweApplication {

    public static void main(String[] args) throws ParserConfigurationException, SAXException {
        SpringApplication.run(DesafioEaweApplication.class, args);

    }

}
