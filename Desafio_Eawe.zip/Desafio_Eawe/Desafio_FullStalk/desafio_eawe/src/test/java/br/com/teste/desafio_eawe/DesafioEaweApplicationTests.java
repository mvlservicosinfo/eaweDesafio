package br.com.teste.desafio_eawe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioEaweApplicationTests {

    @Test
    void contextLoads() {
    }

}
