package org.mvlserviceinfobeta;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.*;
import java.io.File;
import java.io.IOException;


public class XMLLeitura extends DefaultHandler {
    private static final String FILENAME = "C:/exemplo_01.xml";
    public void xlmTeste(){

        try {
            File file = new File("C:/exemplo_01.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.parse(file);
            document.getDocumentElement().normalize();
            System.out.println("Root Element :" + document.getDocumentElement().getNodeName());
            NodeList nList = document.getElementsByTagName("agente");
            NodeList nodeList = document.getElementsByTagName("regiao");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                for(int j=0; j<nodeList.getLength(); j++) {
                    Node nNode = nList.item(temp);
                    Node node = nodeList.item(j);
                    System.out.println("\nCurrent Element :" + nNode.getNodeName());
                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;
                        System.out.println("Codigo: " + eElement.getElementsByTagName("codigo").item(0).getTextContent());
                        System.out.println("data : " + eElement.getElementsByTagName("data").item(0).getTextContent());
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            System.out.println("Regiao Sigla : " + element.getAttribute("sigla"));
                        }
                        System.out.println("geracao : " + eElement.getElementsByTagName("geracao").item(0).getTextContent());
                        System.out.println("compra : " + eElement.getElementsByTagName("compra").item(0).getTextContent());
                        System.out.println("Preço Medio : " + eElement.getElementsByTagName("precoMedio").item(0).getTextContent());
                    }
                }
            }
        } catch (IOException | ParserConfigurationException e) {
            System.out.println(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }
    }




    }



}
